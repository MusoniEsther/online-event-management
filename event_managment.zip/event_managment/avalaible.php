<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="bootstrap-5.3.0-alpha3-dist\bootstrap-5.3.0-alpha3-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="fontawesome-free-6.4.0-web (1)\fontawesome-free-6.4.0-web/css/all.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="row">
<div class="col-lg-12 btn btn-dark"> 
    <p>Admin Dashboard</p> 
    <a href="logout.php" style="float: right;" class="btn btn-danger">log out</a>
</div>
  <div class="row">

<div class="col-lg-8">
  <div class="row mt-8">
    <div class="col-lg-8">
  <h4>Saved events:</h4>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Name</th>
        <th>Start date time</th>
        <th>End date time</th>
        <th>Venue name</th>
        <th>Venue address</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
     <?php
     include "connection.php";

     $select = "SELECT * FROM `events`";
     $result = $conn->query($select);

     

      while ($row=$result->fetch_assoc())
      {
 
        echo "<tr>";

        echo "<td>".$row["name"]."</td>";
        echo "<td>".$row["start_date_time"]."</td>";
        echo "<td>".$row["end_date_time"]."</td>";
        echo "<td>".$row["venue_name"]."</td>";
        echo "<td>".$row["venue_address"]."</td>";
        echo "<td>".$row["status"]."</td>";

        echo "<td><a href='book.php?id=".$row["event_id"]."' class='btn btn-primary'>Book Now</a></td>";

        




        echo "</tr>";

      }


          
     ?>
    </tbody>
  </table>
</div>
  </div>
</div>

  </div>  
</body>
</html>
