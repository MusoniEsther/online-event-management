<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="bootstrap-5.3.0-alpha3-dist\bootstrap-5.3.0-alpha3-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="fontawesome-free-6.4.0-web (1)\fontawesome-free-6.4.0-web/css/all.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="row">
<div class="col-lg-12 btn btn-dark"> 
    <p>Admin Dashboard</p> 
    <a href="logout.php" style="float: right;" class="btn btn-danger">log out</a>
</div>
  <div class="row">
<div class="col-lg-4 btn btn-dark">
<br><br>
    <a href="add.php" style="text-decoration: none; color: white"><h4>add event</h4></a><br>
    <a href="#" style="text-decoration: none; color: white"><h4>view tickets</h4></a><br>
    <a href="#" style="text-decoration: none; color: white"><h4>attended list</h4></a><br>
    
<div class="col-lg-4">
    
</div>
<div class="col-lg-4">
    
</div>
  </div>  
</body>
</html>