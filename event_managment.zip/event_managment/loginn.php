<?php
session_start();
$conn=mysqli_connect("localhost","root","","ester");
if (isset($_POST['login'])) {
   $em=$_POST['email'];
   $pass=$_POST['password'];
   $sel=$conn->query("SELECT * FROM admin WHERE email='$em'");
   if (mysqli_num_rows($sel)>0) {
    $ret=mysqli_fetch_array($sel);
    $em==$ret['email'];
    if ($pass==$ret['password']) {
        // echo"login success";
        $_SESSION['user']=$ret['name'];
        ?>
        <script>
            window.alert("welcome <?php   echo $_SESSION['user']?>");
            window.location.href="pannel.php";
        </script>
        <?php
    }
    else{
        ?>
        <script>
            window.alert(" incorect email or password");
            window.location.href="login.php";
        </script>
        <?php
    }
   }
   else{
  
    ?>
    <script>
        window.alert(" user not found");
        window.location.href="login.php";
    </script>
    <?php
   }
}


?>