<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="bootstrap-5.3.0-alpha3-dist\bootstrap-5.3.0-alpha3-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="fontawesome-free-6.4.0-web (1)\fontawesome-free-6.4.0-web/css/all.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>news</title>
</head>
<body>
   <div class="col-lg-4">
<h3> online event managment system</h3>
   </div>

<div class="row mt-0">
    <div class="col-lg-4">

    </div>
    <div class="btn btn-secondary col-lg-4 mt-5">
<form action="loginn.php" method="POST">
    <i class="fa fa-user"></i><u><h3>log in here</h3></u>
<label>email</label><input type="email" name="email" class="form-control">
<label>password</label><input type="password" name="password" class="form-control"><br>
  


<a href="create.php"><input type="submit" name="cancel" value="create account" class="form-control btn btn-danger mt-2"></a>
</form>


 
 >  
</body>
</html>