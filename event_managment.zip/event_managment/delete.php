<?php

include "connection.php";

if (isset($_GET["id"])) {

$de = "DELETE FROM `events` WHERE `events`.`event_id` = '{$_GET["id"]}'";

$res = $conn->query($de);

if ($de) {

	echo "data deleted";
}

else {

	echo "something went wrong!";
}

}


?>