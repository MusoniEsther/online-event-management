<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="bootstrap-5.3.0-alpha3-dist\bootstrap-5.3.0-alpha3-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="fontawesome-free-6.4.0-web (1)\fontawesome-free-6.4.0-web/css/all.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="row">
<div class="col-lg-12 btn btn-dark"> 
    <p>Admin Dashboard</p> 
    <a href="logout.php" style="float: right;" class="btn btn-danger">log out</a>
</div>
  <div class="row">
<div class="col-lg-4 btn btn-dark">
<br><br>

    <a href="#" style="text-decoration: none; color: white"><h4>add event</h4></a><br>
    <a href="#" style="text-decoration: none; color: white"><h4>view tickets</h4></a><br>
    <a href="#" style="text-decoration: none; color: white"><h4>attended list</h4></a><br>
    
</div>
<div class="col-lg-4">
  <div class="row mt-4">
    <div class="col-lg-8">
      <div class="btn btn-secondary col-lg-12 mt-2">
        <form action="" method="POST">
          <i class="fa fa-user"></i><u><h3>EVENT ADDITIONAL</h3></u>
          <label>name</label><input type="text" name="name" class="form-control">
          <label>start date time</label><input type="date" name="start_time" class="form-control"><br>
          <label>end date time</label><input type="date" name="end_time" class="form-control">
          <label>venue name</label><input type="text" name="venue_name" class="form-control"><br>
          <label>venue address</label><input type="text" name="venue_address" class="form-control">
          <label>status</label><input type="text" name="status" class="form-control"><br>
          <input type="submit" name="submit" value="send" class="form-control btn btn-success">
          
        </form>
      </div>
    </div>
    <div class="col-lg-4">
  <h4>Saved events:</h4>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Name</th>
        <th>Start date time</th>
        <th>End date time</th>
        <th>Venue name</th>
        <th>Venue address</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
     <?php
     include "connection.php";

     $select = "SELECT * FROM `events`";
     $result = $conn->query($select);

     

      while ($row=$result->fetch_assoc())
      {

        echo "<tr>";

        echo "<td>".$row["name"]."</td>";
        echo "<td>".$row["start_date_time"]."</td>";
        echo "<td>".$row["end_date_time"]."</td>";
        echo "<td>".$row["venue_name"]."</td>";
        echo "<td>".$row["venue_address"]."</td>";
        echo "<td>".$row["status"]."</td>";

        echo "<td><button class ='btn btn-danger'><a style='color:white;' href='delete.php?id=$row[event_id]'>Delete</a><button></td>";
        




        echo "</tr>";

      }


          
     ?>
    </tbody>
  </table>
</div>
  </div>
</div>

  </div>  
</body>
</html>

<?php
include("connection.php");

if (isset($_POST["submit"])){


$name = $_POST['name'];
$start_time = $_POST['start_time'];
$end_time = $_POST['end_time'];
$venue_name = $_POST['venue_name'];
$venue_address = $_POST['venue_address'];
$status = $_POST['status'];


$$insert = $conn->query("INSERT INTO `events` VALUES  ('','$name', '$start_time', '$end_time', '$venue_name', '$venue_address', '$status')");

if ($insert) {
 
  echo "Event created successfully";
} else {
  
  echo "Error: " . $insert->error;
}


$insert->close();
$conn->close();
}


?>