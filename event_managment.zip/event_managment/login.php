<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="bootstrap-5.3.0-alpha3-dist\bootstrap-5.3.0-alpha3-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="fontawesome-free-6.4.0-web (1)\fontawesome-free-6.4.0-web/css/all.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>news</title>
</head>
<body>
   <div class="row alert alert-dark">
   <div class="col-lg-4">
    <br>
    <br>
<a href="avalaible.php" class="btn btn-primary">available events</a>
   </div>
   <div class="col-lg-4">
<h3> online event managment system</h3>
   </div>
   <div class="col-lg-4">
   <br>
    <br>
<a href="login.php" class="btn btn-danger" style="float:right;">log in</a>
   </div>
   </div> 
   <div class="row">
   <center>
   <div class="col-lg-4">
    
    <form action="#" method="POST">
      <input type="search" name="find" placeholder="search an event">
      <button class="btn btn-primary"><input type="submit" name="send" placeholder="search an event" value="search" ></button>
    </form>
   </div>
</center>
</div>
<div class="row mt-0">
    <div class="col-lg-4">

    </div>
    <div class="btn btn-secondary col-lg-4 mt-5">
<form action="loginn.php" method="POST">
    <i class="fa fa-user"></i><u><h3>log in here</h3></u>
<label>email</label><input type="email" name="email" class="form-control">
<label>password</label><input type="password" name="password" class="form-control"><br>
<input type="submit" name="login" value="login" class="form-control btn btn-success">
  
  <h4>Or create account</h4>

<a href="create.php"><input type="reset" name="cancel"  class="form-control btn btn-danger mt-2">create account</a>
</form>


    </div>
   <div class="col-lg-4">

    </div>

<br>
<br>
<br>
 <div class="row alert alert-dark">
    <div class=" mt-0 col-lg-4">
  <h4>follow us on:
   <br>
   <a href="#"><i class="fab fa-whatsapp"></i></a> 
   <a href="#"><i class="fab fa-twitter"></i></a>
   <a href="#"><i class="fab fa-instagram"></i></a>

   </div>
   <div class=" mt-0 col-lg-4">
  <p>developed by UME developer tech</p>
  <p>copy&copy at UME developer tech ltd</p>

   </div>
   <div class=" mt-0 col-lg-4">
  <h4>location and contact:</h4>
  <p>we are located at kigali/chic F1R4</p>
  <p>contact us on:0781727465</p>

   </div>
   </div>  
</body>
</html>