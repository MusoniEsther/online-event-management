<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ester";

$conn = new mysqli($servername, $username, $password, $dbname);


?>